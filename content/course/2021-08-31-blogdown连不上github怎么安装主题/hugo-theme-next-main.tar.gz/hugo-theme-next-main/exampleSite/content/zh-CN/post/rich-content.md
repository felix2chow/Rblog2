+++
author = "Hugo Authors"
title = "富文本内容测试"
date = "2019-03-10"
description = "A brief description of Hugo Shortcodes"
tags = [
    "shortcodes",
    "privacy",
]
+++

Hugo上有几个[**内置短代码**](https://gohugo.io/content-management/shortcodes/#use-hugos)，用于丰富内容，以及[**隐私配置**](https://gohugo.io/about/hugo-and-gdpr/)还有一组简单的短代码，支持各种社交媒体嵌入的静态和非JS版本。

<!--more-->

---

## YouTube Privacy Enhanced Shortcode

{{< youtube ZJthWmvUzzc >}}

<br>

---

## Twitter Simple Shortcode

{{< twitter_simple 1085870671291310081 >}}

<br>

---

## Vimeo Simple Shortcode

{{< vimeo_simple 48912912 >}}

